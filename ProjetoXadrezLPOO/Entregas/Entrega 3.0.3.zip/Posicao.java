package ProjetoXadrezLPOO;

public abstract class Posicao {
    //essa classe define os elementos do tabuleiro

    protected String print;
    public String cor;
    public String tipo;
    public boolean mexeu;
    public boolean xeque = false;
//    int[] posicaoInicial = new int[2];

    public Posicao(String tipoRecebido){
        this.tipo = tipoRecebido;
    }

//    public void setPosicaoInicial(int x, int y){
//        posicaoInicial[0] = x;
//        posicaoInicial[1] = y;
//    }

    public boolean isMexeu(){
        return mexeu;
    }

    public boolean isXeque(){ //posicao = Jogo.posicao[y][x];
//        int[] checarDe = posicaoInicial;
//        Posicao inicio = Jogo.posicao[checarDe[1]][checarDe[0]];
//        cor = inicio.cor();
//        for(int i = 0; i < 8; i++){
//            if(checarDe[1]-i >= 0 && checarDe[1]+i >= 0){
//            Posicao direcao = Jogo.posicao[checarDe[1] - i][checarDe[0] - i];
//            //testarRiscoDiagonal(inicio, direcao, i, cor);
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            else{
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                    return true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("peao") && !(direcao.cor().equals(cor))){
//                    return true;
//                }
//                else{
//                    risco = false;
//                }
//            }
//
//            direcao = Jogo.posicao[checarDe[1] - i][checarDe[0] + i];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            else{
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                    return true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("peao") && !(direcao.cor().equals(cor))){
//                    return true;
//                }
//                else{
//                    risco = false;
//                }
//            }
//            direcao = Jogo.posicao[checarDe[1] + i][checarDe[0] - i];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            else{
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                    return true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("peao") && !(direcao.cor().equals(cor))){
//                    return true;
//                }
//                else{
//                    risco = false;
//                }
//            }
//            direcao = Jogo.posicao[checarDe[1] + i][checarDe[0] + i];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            else{
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                    return true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && (direcao.tipo().equals("peao") || direcao.tipo().equals("rei")) && !(direcao.cor().equals(cor))){
//                    return true;
//                }
//                else{
//                    risco = false;
//                }
//            }
//            direcao = Jogo.posicao[checarDe[1]][checarDe[0] + i];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                return true;
//            }
//            else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                return true;
//            }
//            else{
//                risco = false;
//            }
//            direcao = Jogo.posicao[checarDe[1]][checarDe[0] - i];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                return true;
//            }
//            else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                return true;
//            }
//            else{
//                risco = false;
//            }
//            direcao = Jogo.posicao[checarDe[1] + i][checarDe[0]];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                return true;
//            }
//            else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                return true;
//            }
//            else{
//                risco = false;
//            }
//            direcao = Jogo.posicao[checarDe[1] - i][checarDe[0]];
//            if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                risco = false;
//                continue;
//            }
//            if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                return true;
//            }
//            else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                return true;
//            }
//            else{
//                risco = false;
//            }
//            for(int a = -3; a < 3; a++){
//                for(int b = -3; b < 3; b++){
//                    if(a != 0 && b != 0){
//                        direcao = Jogo.posicao[checarDe[1] + a][checarDe[0] + b];//cavalo
//                        int soma = a + b;
//                        switch (soma) {
//                            case 1:
//                                if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                    return true;
//                                }
//                            case -1:
//                                if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                    return true;
//                                }
//                            case 3:
//                                if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                    return true;
//                                }
//                            case -3:
//                                if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                    return true;
//                                }
//                            default:
//                                risco = false;
//                        }
//                    }
//                }
//            }
//        }
//    }
        return xeque;
    }

    public void setXeque(boolean xeque){
        this.xeque = xeque;
    }

    String print(){
        return print;
    }

    public String cor(){
        return cor;
    }

    public String tipo(){
        return tipo;
    }
    public abstract boolean movimento(int[] moverDe, int[] moverPara, String corPeca, boolean xeque);
}