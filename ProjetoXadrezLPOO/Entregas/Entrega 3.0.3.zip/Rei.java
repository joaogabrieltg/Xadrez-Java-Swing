package ProjetoXadrezLPOO;

public class Rei extends Peca {

    boolean mexeu = false;
    int[] posicaoInicial = new int[2];

    public Rei(String corPeca){
        //define o tipo e cor da peca
        super(corPeca, "rei");
        if(cor.equals("branco")){
            print = "  R  ";
        }
        else{
            print = "  r: ";
        }
    }

    public boolean movimento(int[] moverDe, int[] moverPara, String corPeca, boolean xeque){

        Posicao posicao = Jogo.posicao[moverPara[1]][moverPara[0]];//posicao inicializada
        Posicao inicio = Jogo.posicao[moverDe[1]][moverDe[0]];

//        //-----------------------------------------------------------------------------
//        for(int i = 0; i < 8; i++){
//            if(moverDe[1]-i >= 0 && moverDe[1]+i >= 0){
//                Posicao direcao = Jogo.posicao[moverDe[1] - i][moverDe[0] - i];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                else{
//                    if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                        risco = true;
//                    }
//                    else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("peao") && !(direcao.cor().equals(cor))){
//                        risco = true;
//                    }
//                    else{
//                        risco = false;
//                    }
//                }
//
//                direcao = Jogo.posicao[moverDe[1] - i][moverDe[0] + i];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                else{
//                    if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                        risco = true;
//                    }
//                    else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("peao") && !(direcao.cor().equals(cor))){
//                        risco = true;
//                    }
//                    else{
//                        risco = false;
//                    }
//                }
//                direcao = Jogo.posicao[moverDe[1] + i][moverDe[0] - i];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                else{
//                    if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                        risco = true;
//                    }
//                    else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("peao") && !(direcao.cor().equals(cor))){
//                        risco = true;
//                    }
//                    else{
//                        risco = false;
//                    }
//                }
//                direcao = Jogo.posicao[moverDe[1] + i][moverDe[0] + i];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                else{
//                    if(direcao.tipo().equals("dama") || direcao.tipo().equals("bispo")){
//                        risco = true;
//                    }
//                    else if(i == 1 && inicio.cor().equals(cor) && (direcao.tipo().equals("peao") || direcao.tipo().equals("rei")) && !(direcao.cor().equals(cor))){
//                        risco = true;
//                    }
//                    else{
//                        risco = false;
//                    }
//                }
//                direcao = Jogo.posicao[moverDe[1]][moverDe[0] + i];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                    risco = true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                    risco = true;
//                }
//                else{
//                    risco = false;
//                }
//                direcao = Jogo.posicao[moverDe[1]][moverDe[0] - i];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                    risco = true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                    risco = true;
//                }
//                else{
//                    risco = false;
//                }
//                direcao = Jogo.posicao[moverDe[1] + i][moverDe[0]];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                    risco = true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                    risco = true;
//                }
//                else{
//                    risco = false;
//                }
//                direcao = Jogo.posicao[moverDe[1] - i][moverDe[0]];
//                if(direcao.cor().equals(inicio.cor()) || direcao.tipo().equals("vazio")){
//                    risco = false;
//                    continue;
//                }
//                if(direcao.tipo().equals("dama") || direcao.tipo().equals("torre")){
//                    risco = true;
//                }
//                else if(i == 1 && inicio.cor().equals(cor) && direcao.tipo().equals("rei") && !(direcao.cor().equals(cor))){
//                    risco = true;
//                }
//                else{
//                    risco = false;
//                }
//                for(int a = -3; a < 3; a++){
//                    for(int b = -3; b < 3; b++){
//                        if(a != 0 && b != 0){
//                            direcao = Jogo.posicao[moverDe[1] + a][moverDe[0] + b];//cavalo
//                            int soma = a + b;
//                            switch (soma) {
//                                case 1:
//                                    if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                        risco = true;
//                                        break;
//                                    }
//                                case -1:
//                                    if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                        risco = true;
//                                        break;
//                                    }
//                                case 3:
//                                    if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                        risco = true;
//                                        break;
//                                    }
//                                case -3:
//                                    if(direcao.tipo().equals("cavalo") && !(direcao.cor().equals(cor))){
//                                        risco = true;
//                                        break;
//                                    }
//                                default:
//                                        risco = false;
//                                        break;
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        //-----------------------------------------------------------------------------

        //1 casa para frente ou trás ou esquerda ou direita ou NE ou NO ou SE ou SO

        for(int AlcanceX = -1; AlcanceX <= 1; AlcanceX++){
            for(int AlcanceY = -1; AlcanceY <= 1; AlcanceY++){
                if(moverPara[0] == moverDe[0] + AlcanceX && moverPara[1] == moverDe[1] + AlcanceY){//exceto em captura e se a posicao desejada for vazia

//                    if(!xeque){
                        if(((!posicao.tipo().equals("vazio")) && (!posicao.cor().equals(corPeca))) || (posicao.tipo().equals("vazio"))){
                            this.mexeu=true;
                            return true;
                        }
//                    }
//                    else{
//                        System.out.println("Nao faca isso! Seu rei entrara em cheque!");
//                    }
                }
            }
        }
        return false;
    }


    @Override
    public boolean isMexeu(){
        return mexeu;
    }
}