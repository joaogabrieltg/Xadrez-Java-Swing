package ProjetoXadrezLPOO;
import java.util.Scanner;

public class Jogo {

    static final char[] coordLetra = {'A','B','C','D','E','F','G','H','I'};//coodenadas horizontais
    static final int[] coordNumero = {1,2,3,4,5,6,7,8,9};//coordenadas verticais
    public static Posicao[][] posicao = new Posicao[8][8];
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {

        int desistencia = 0;
        String jogador1 = nome(1, null);
        String jogador2 = nome(2, jogador1);
        Jogador jogadorBranco = new Jogador(jogador1, "branco");
        Jogador jogadorPreto = new Jogador(jogador2, "preto");

        posicionar();//organizar as pecas no tabuleiro

        do {//loop principal de jogo
            for (int rodada = 1; rodada <= 2; rodada++){//rodada 1 e de onde sai, 2 e para onde vai
                if (desistencia == 0) {//garante que o tabuleiro fecha em caso de desistencia
                    printarTabuleiro();
                }

                int[][] movimento;

                while (true) {
                    if(desistencia == 0){//garante que nao sera mais pedido nada em caso de desistencia
                        if (rodada == 1) {
                            movimento = jogadorBranco.jogada();
                        }
                        else{
                            movimento = jogadorPreto.jogada();
                        }
                    }
                    else{
                        break;
                    }

                    if (movimento[0][0] == -1) {
                        System.out.println("Localizacao invalida. Tente de novo");
                        continue;
                    }

                    if (movimento[0][0] == -2) {
                        System.out.println("Desistencia confirmada");
                        desistencia++;
                        break;
                    }

                    else{
                        Posicao posicao = Jogo.posicao[movimento[0][1]][movimento[0][0]];
                        boolean movimentoValido;

                        if (rodada == 1) {//checa se o movimento do branco e valido
                            movimentoValido = posicao.movimento(movimento[0], movimento[1], "branco");
                        }

                        else{//checa se o movimento do preto e valido
                            movimentoValido = posicao.movimento(movimento[0], movimento[1], "preto");
                        }

                        if (movimentoValido) {
                            limparPosicao(movimento[0], movimento[1]);//caso o movimento seja valido a posicao inicial e apagada e o peao se move
                            break;//reinicia o loop de rodada
                        }
                        System.out.println("Jogada invalida. Tente de novo");
                    }
                }
            }
        }while (desistencia == 0);//roda enquanto nao ha desistencia
    }

    private static String nome(int numeroJogador, String nomeAnterior){

        String nome;

        while(true){//leitura dos nomes
            System.out.print("Jogador " + numeroJogador + " digite seu nome:\n ");
            nome = scan.nextLine();

            if(!nome.isEmpty() && !nome.equals(nomeAnterior)) {//checa se o nome esta vazio ou e igual ao anterior
                break;
            }

            else{
                System.out.println("Nome invalido. Tente de novo.");
            }
        }
        return nome;
    }

    private static void posicionar(){

        for(int i = 0; i < 8; i++){
            posicao[1][i] = new Peao("preto", i);//peoes de cima
        }

        posicao[0][0] = new Torre("preto" , 1);
        posicao[0][1] = new Cavalo("preto", 1);
        posicao[0][2] = new Bispo("preto", 1);
        posicao[0][3] = new Dama("preto");
        posicao[0][4] = new Rei("preto");
        posicao[0][5] = new Bispo("preto", 2);
        posicao[0][6] = new Cavalo("preto", 2);
        posicao[0][7] = new Torre("preto", 2);

        for(int i = 2; i < 6; i++){
            for(int j = 0; j < 8; j++){
                posicao[i][j] = new Limpar();//vazio do meio
            }
        }

        for(int i = 0; i < 8; i++){
            posicao[6][i] = new Peao("branco" , i);//peoes de baixo
        }

        posicao[7][0] = new Torre("branco", 1);
        posicao[7][1] = new Limpar();//posicao[7][1] = new Cavalo("branco", 1);
        posicao[7][2] = new Limpar();//posicao[7][2] = new Bispo("branco", 1);
        posicao[7][3] = new Limpar();//posicao[7][3] = new Dama("branco");
        posicao[7][4] = new Rei("branco");
        posicao[7][5] = new Limpar();//posicao[7][5] = new Bispo("branco", 2);
        posicao[7][6] = new Limpar();//posicao[7][6] = new Cavalo("branco", 2);
        posicao[7][7] = new Torre("branco", 2);

    }

    private static void limparPosicao(int[] moverDe, int[] moverPara){//limpa posicao inicial apos um movimento
        posicao[moverPara[1]][moverPara[0]] = posicao[moverDe[1]][moverDe[0]];
        posicao[moverDe[1]][moverDe[0]] = new Limpar();
    }

    private static void printarTabuleiro(){//design do tabuleiro

        System.out.print("\n   ");

        for(int i = 0; i < (Jogo.coordLetra.length-1); i++){//para no h pois o I é apenas para desistencia, letras em cima
            System.out.print("  -" + Jogo.coordLetra[i] + "- ");
        }

        System.out.print("\n   ");

        for(int i = 0; i < 8; i++){//divisor das letras de cima pro tabuleiro
            System.out.print("=-----");
        }

        System.out.print("=\n");

        for(int i = 0; i < 8; i++){//numeros a esquerda

            System.out.print("-" + (8 - i) + " |");

            for(Posicao j: posicao[i]){//printa o que esta na posicao, seja peca ou vazio
                System.out.print(j.print() + "|");
            }

            System.out.print(" " + (8 - i) + "-");//numeros a direita
            System.out.print("\n   ");

            for(int j = 0; j < 8; j++){//divisor entre os espacos
                System.out.print("=-----");
            }

            System.out.print("=\n");

        }

        System.out.print("   ");

        for(int i = 0; i < (Jogo.coordLetra.length-1); i++){//letras em baixo
            System.out.print("  -" + Jogo.coordLetra[i] + "- ");
        }

        System.out.print("\n  -COMANDO PARA DESISTENCIA >>>> I9:I9 OU \"DESISTIR\"-  \n\n");

    }
    /*
    private static boolean roque(){

    return true;
    }
    *///pre protoripo de roque
}