package ProjetoXadrezLPOO;

public abstract class Posicao {
    //essa classe define os elementos do tabuleiro

    protected String print;
    public String cor;
    public String tipo;

    public Posicao(String tipoRecebido){
        this.tipo = tipoRecebido;
    }

    String print(){
        return print;
    }

    public String cor(){
        return cor;
    }

    public String tipo(){
        return tipo;
    }
    public abstract boolean movimento(int[] moverDe, int[] moverPara, String corPeca);
}
