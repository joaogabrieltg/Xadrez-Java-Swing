package ProjetoXadrezLPOO;

public class Rei extends Peca {

    int contadorDeMovimento;

    public Rei(String corPeca){
        //define o tipo e cor da peca
        super(corPeca, "rei");
        if(cor.equals("branco")){
            print = "  R  ";
        }
        else{
            print = "  r: ";
        }
    }

    public boolean movimento(int[] moverDe, int[] moverPara, String corPeca){

        Posicao posicao = Jogo.posicao[moverPara[1]][moverPara[0]];//posicao inicializada
        int aux;
        contadorDeMovimento = 0;

        //1 casa para frente ou trás ou esquerda ou direita ou NE ou NO ou SE ou SO
        for(int AlcanceX = -1; AlcanceX <= 1; AlcanceX++){
            for(int AlcanceY = -1; AlcanceY <= 1; AlcanceY++){
                if(moverPara[0] == moverDe[0] + AlcanceX && moverPara[1] == moverDe[1] + AlcanceY){//exceto em captura e se a posicao desejada for vazia
                    if(((!posicao.tipo().equals("vazio")) && (!posicao.cor().equals(corPeca))) || (posicao.tipo().equals("vazio"))){
                        this.contadorDeMovimento = contadorDeMovimento++;
                        return true;
                    }
                }
            }
        }
        /*
        for(int AlcanceX = -2; AlcanceX <= 2; AlcanceX++){
            for(int i = 1; i <= AlcanceX; i++){
                if(moverPara[1] == moverDe[1] && moverPara[0] > moverDe[0]){//para a direita
                    posicao = Jogo.posicao[moverDe[1]][moverDe[0] + i];
                    aux = (moverDe[0]+i)+1;
                }
                else if(moverPara[1] == moverDe[1] && moverPara[0] < moverDe[0]){//para a esquerda
                    posicao = Jogo.posicao[moverDe[1]][moverDe[0] - i];
                    aux = (moverDe[0]-i)-2;
                }
                else{
                    return false;
                }
                Posicao[][] roque = new Posicao[8][8];
                Posicao posicaoRoque;
                if(corPeca == "branco"){
                    if(aux > 0){
                        posicaoRoque = Jogo.posicao[7][0];
                    }
                    else{
                        posicaoRoque = Jogo.posicao[7][7];
                    }
                }
                else if(corPeca == "preto"){
                    if(aux > 0){
                        posicaoRoque = Jogo.posicao[0][0];
                    }
                    else{
                        posicaoRoque = Jogo.posicao[0][7];
                    }
                }
                else{
                    return false;
                }
                if((!posicao.tipo().equals("vazio")) && (i != AlcanceX)){
                    return false;
                }
                else if((i == AlcanceX) && (posicao.tipo().equals("vazio")) && posicaoRoque.tipo().equals("torre")){
                    //exceto em captura e se a posicao desejada for vazia
                    if(corPeca == "preto"){
                        roque[0][aux] = new Torre("preto");
                    }
                    else{
                        roque[7][aux] = new Torre("branco");
                    }
                    contadorDeMovimento++;
                    return true;
                }
            }
        }
         *///prototipo de roque
        return false;
    }
}