package ProjetoXadrezLPOO;

public abstract class Peca extends Posicao {
    //essa classe serve para definir os tipos de peca, por hora somente o peao
    public Peca(String corPeca, String tipoRecebido) {
        super(tipoRecebido);
        cor = corPeca;
    }
}
