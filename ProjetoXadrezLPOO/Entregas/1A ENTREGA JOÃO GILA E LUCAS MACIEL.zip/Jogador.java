package ProjetoXadrezLPOO;
import java.util.Scanner;

public class Jogador {
    private final String nome;
    private final String corJogador;
    Scanner scan = new Scanner(System.in);

    Jogador(String nome, String corJogador){//identificador de jogador
        this.nome = nome;
        this.corJogador = corJogador;
    }

    private int letraParaInt(char caractere){ //transforma o char recebido em int
        int coordenadaL = -1;

        for(int i = 0; i < Jogo.coordLetra.length; i++){
            if(Jogo.coordLetra[i] == caractere){
                coordenadaL = i;
                if(caractere == 'I' || caractere == 'i'){// i=-2 pra desistir
                    coordenadaL = -2;
                }
            }
        }
        return coordenadaL;
    }

    private int numeroparaInt(char coordNumero){ //transforma o char(numero) recebido em int
        int coordenadaN = -1;
        int numeroInt = Character.getNumericValue(coordNumero);

        for(int i = 0; i < Jogo.coordNumero.length; i++) {
            if (i == numeroInt) {
                coordenadaN = numeroInt;
                break;
            }
        }
        if (numeroInt == 9) {// 9=-2 pra desistir
            coordenadaN = -2;
        }
        return coordenadaN;
    }

    public int[][] jogada(){
        int[][] jogada = new int[2][2];
        for(int escolha = 1; escolha <= 2; escolha++) {//pergunta de onde e para onde
            while (true) {
                if (escolha == 1) {
                    System.out.println(nome + ", digite a coordenada de sua peca. (no modelo: LetraNumero)");
                }
                else{
                    System.out.println(nome + ", digite a coordenada para onde quer ir. (no modelo: LetraNumero)");
                }
                String entrada = scan.nextLine().trim();//e recebe o dado

                if (entrada.length() == 2 && !entrada.contains(" ")) {//checando caracteres e tamanhos validos
                    int letra = letraParaInt(Character.toUpperCase(entrada.charAt(0)));//letra -> numero
                    int numero = numeroparaInt(entrada.charAt(1));//letra numero -> numero

                    if (letra != -1 && letra != -2){//se não desistiu e é caracter válido
                        if (numero != -1 && numero != -2){//se não desistiu e é numero válido
                            numero = 8 - numero;//inverter pq o tabuleiro esta de cabeca para baixo
                            int[] coord = {letra, numero};
                            if (escolha == 1) {//repete pro 2
                                if (Jogo.posicao[numero][letra].tipo().equals("vazio") || !Jogo.posicao[numero][letra].cor().equals(corJogador)) {//checa se tem peca(por isso e feito antes do 2)
                                    coord[0] = -1;
                                    coord[1] = -1;
                                    return new int[][]{coord, coord};//saida -1 -1, invalido
                                }
                            }
                            jogada[escolha - 1] = coord;
                            break;
                        }
                    }
                    if (letra == -2 && numero == -2){//comando para a desistencia
                        int[] coord = {letra, numero};
                        return new int[][]{coord, coord};
                    }
                }
                System.out.println("Localização inválida, tente de novo");
            }
        }
        return jogada;
    }
}