package ProjetoXadrezLPOO;

public class Bispo extends Peca{
    public Bispo(String corPeca){
        //define o tipo e cor da peca
        super(corPeca, "bispo");
        if(cor.equals("branco")){
            print = "  B  ";
        }
        else{
            print = "  b: ";
        }
    }

    @Override
    public boolean movimento(int[] moverDe, int[] moverPara, String corPeca){

        Posicao posicao;

        int caminho;
        //verifica se o movimento é valido
        if(moverPara[0] > moverDe[0]){
            caminho = (moverPara[0] - moverDe[0]);
        }
        else if(moverPara[0] < moverDe[0]){
            caminho = (moverDe[0] - moverPara[0]);
        }
        else if(moverPara[1] > moverDe[1]){
            caminho = (moverPara[1] - moverDe[1]);
        }
        else if(moverPara[1] < moverDe[1]){
            caminho = (moverDe[1] - moverPara[1]);
        }
        else{
            return false;
        }
        for(int i = 1; i <= caminho; i++){
            if(moverPara[1] < moverDe[1] && moverPara[0] < moverDe[0]){//para sudoeste
                posicao = Jogo.posicao[moverDe[1] - i][moverDe[0] - i];
            }
            else if(moverPara[1] < moverDe[1] && moverPara[0] > moverDe[0]){//para sudeste
                posicao = Jogo.posicao[moverDe[1] - i][moverDe[0] + i];
            }
            else if(moverPara[1] > moverDe[1] && moverPara[0] < moverDe[0]){//para noroeste
                posicao = Jogo.posicao[moverDe[1] + i][moverDe[0] - i];
            }
            else if(moverPara[1] > moverDe[1] && moverPara[0] > moverDe[0]){//para nordeste
                posicao = Jogo.posicao[moverDe[1] + i][moverDe[0] + i];
            }
            else{
                return false;
            }
            if((!posicao.tipo().equals("vazio")) && (i != caminho) && posicao.cor().equals(corPeca)){
                return false;
            }
            else if((i == caminho) && ((posicao.tipo().equals("vazio")) || (!posicao.cor().equals(corPeca)))){//exceto em captura e se a posicao desejada for vazia
                return true;
            }
        }
        return false;
    }

}