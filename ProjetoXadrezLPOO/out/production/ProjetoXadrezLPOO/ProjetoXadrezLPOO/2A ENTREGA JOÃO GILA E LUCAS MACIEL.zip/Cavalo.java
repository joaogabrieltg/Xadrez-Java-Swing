package ProjetoXadrezLPOO;

public class Cavalo extends Peca{
    public Cavalo(String corPeca) {
//define o tipo e cor da peca
        super(corPeca, "cavalo");

        if(cor.equals("branco")){
            print = "  C  ";
        }
        else{
            print = "  c: ";
        }
    }

    public boolean movimento(int[] moverDe, int[] moverPara, String corPeca) {

        int posicaoRelativaX = moverPara[0]-moverDe[0];
        int posicaoRelativaY = moverPara[1]-moverDe[1];

        boolean valido = false;
        Posicao posicao = Jogo.posicao[moverPara[1]][moverPara[0]];

        if (posicaoRelativaX !=0 && posicaoRelativaY !=0) {
            int movimento = posicaoRelativaX + posicaoRelativaY;
            valido = switch (movimento) {
                case 1, -1, 3, -3 -> true; //esse intellij e bao msm
                default -> false;
            };
        }
        if(valido){ //if the location was not within a knights move rules
            return posicao.tipo().equals("vazio") || (!posicao.cor().equals(corPeca));
        }
        return false;
    }
}
