package ProjetoXadrezLPOO;

public class Dama extends Peca{

    public Dama(String corPeca){
        //define o tipo e cor da peca
        super(corPeca, "dama");
        if(cor.equals("branco")){
            print = "  D  ";
        }
        else{
            print = "  d: ";
        }
    }

    public boolean movimento(int[] moverDe, int[] moverPara, String corPeca){

        Posicao posicao;
        int caminho;

        //condicionais e loops que verificam se o movimento da dama é valido
        if(moverPara[0] > moverDe[0]){
            caminho = (moverPara[0] - moverDe[0]);
        }
        else if(moverPara[0] < moverDe[0]){
            caminho = (moverDe[0] - moverPara[0]);
        }
        else if(moverPara[1] > moverDe[1]){
            caminho = (moverPara[1] - moverDe[1]);
        }
        else if(moverPara[1] < moverDe[1]){
            caminho = (moverDe[1] - moverPara[1]);
        }
        else{
            return false;
        }

        for(int i = 1; i <= caminho; i++){
            if(moverPara[1] < moverDe[1] && moverPara[0] < moverDe[0]){//para sudoeste
                posicao = Jogo.posicao[moverDe[1] - i][moverDe[0] - i];
            }
            else if(moverPara[1] < moverDe[1] && moverPara[0] > moverDe[0]){//para sudeste
                posicao = Jogo.posicao[moverDe[1] - i][moverDe[0] + i];
            }
            else if(moverPara[1] > moverDe[1] && moverPara[0] < moverDe[0]){//para noroeste
                posicao = Jogo.posicao[moverDe[1] + i][moverDe[0] - i];
            }
            else if(moverPara[1] > moverDe[1] && moverPara[0] > moverDe[0]){//para nordeste
                posicao = Jogo.posicao[moverDe[1] + i][moverDe[0] + i];
            }
            else if(moverPara[1] == moverDe[1] && moverPara[0] > moverDe[0]){//para a direita
                posicao = Jogo.posicao[moverDe[1]][moverDe[0] + i];
            }
            else if(moverPara[1] == moverDe[1] && moverPara[0] < moverDe[0]){//para a esquerda
                posicao = Jogo.posicao[moverDe[1]][moverDe[0] - i];
            }
            else if(moverPara[1] > moverDe[1]){//para frente
                posicao = Jogo.posicao[moverDe[1] + i][moverDe[0]];
            }
            else if(moverPara[1] < moverDe[1]){//para trás
                posicao = Jogo.posicao[moverDe[1] - i][moverDe[0]];
            }
            else{
                return false;
            }

            if((!posicao.tipo().equals("vazio")) && (i != caminho)){
                return false;
            }
            else if((i == caminho) && ((posicao.tipo().equals("vazio")) || (!posicao.cor().equals(corPeca)))){//exceto em captura e se a posicao desejada for vazia
                return true;
            }
        }
        return false;
    }
}
