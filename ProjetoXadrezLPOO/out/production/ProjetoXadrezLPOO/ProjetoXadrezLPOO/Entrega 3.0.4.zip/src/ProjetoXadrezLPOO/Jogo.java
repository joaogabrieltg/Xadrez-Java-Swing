package ProjetoXadrezLPOO;
import java.util.Arrays;
import java.util.Scanner;

public class Jogo {

    static final char[] coordLetra = {'A','B','C','D','E','F','G','H','I'};//coodenadas horizontais
    static final int[] coordNumero = {1,2,3,4,5,6,7,8,9};//coordenadas verticais
    public static Posicao[][] posicao = new Posicao[8][8];
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {

        int desistencia = 0;
        String jogador1 = nome(1, null);
        String jogador2 = nome(2, jogador1);
        Jogador jogadorBranco = new Jogador(jogador1, "branco");
        Jogador jogadorPreto = new Jogador(jogador2, "preto");
        posicionar();//organizar as pecas no tabuleiro

        do {//loop principal de jogo
            for(int rodada = 1; rodada <= 2; rodada++){//rodada 1 e de onde sai, 2 e para onde vai
                if(desistencia == 0){//garante que o tabuleiro fecha em caso de desistencia
                    printarTabuleiro();
                }

                int[][] movimento;

                while (true) {
                    String corInimiga;
                    String cor;
                    if(desistencia == 0){//garante que nao sera mais pedido nada em caso de desistencia
                        if(rodada == 1){
                            movimento = jogadorBranco.jogada();
                        }
                        else{
                            movimento = jogadorPreto.jogada();
                        }
                    }
                    else{
                        break;
                    }

                    if (movimento[0][0] == -1) {
                        System.out.println("Localizacao invalida. Tente de novo");
                        continue;
                    }

                    if (movimento[0][0] == -2) {
                        System.out.println("Desistencia confirmada");
                        desistencia++;
                        break;
                    }

                    else{
                        Posicao posicaoPeca = Jogo.posicao[movimento[0][1]][movimento[0][0]];
                        boolean movimentoValido;
                        //                 boolean reiBrancoOk = (posicao[7][4].tipo().equals("rei") && !posicao[7][4].isMexeu());
                        //                 boolean reiPretoOk = (posicao[0][4].tipo().equals("rei") && !posicao[0][4].isMexeu());
                        //                 boolean torreBrancaEsq = (posicao[7][0].tipo().equals("torre") && !posicao[7][0].isMexeu());
                        //                 boolean torreBrancaDir = (posicao[7][7].tipo().equals("torre") && !posicao[7][7].isMexeu());
                        //                 boolean torrePretaEsq = (posicao[0][0].tipo().equals("torre") && !posicao[0][0].isMexeu());
                        //                 boolean torrePretaDir = (posicao[0][7].tipo().equals("torre") && !posicao[0][7].isMexeu());
                        if (rodada == 1){//checa se o movimento do branco e valido
                            //                        if(movimento[0][0] == -3){//roque grande
                            //                            if(reiBrancoOk && torreBrancaEsq){
                            //
                            //                            }
                            //                        }
                            //                        else if(movimento[0][0] == -4){//roque pequeno
                            //                            if(reiBrancoOk && torreBrancaDir){
                            //
                            //                            }
                            //                            else{
                            //movimentoValido = posicaoPeca.movimento(movimento[0], movimento[1], "branco", false);
                            movimentoValido = posicaoPeca.movimento(movimento[0], movimento[1], "branco");
                            //                            }
                            //                        }
                        }

                        else{
                            //checa se o movimento do preto e valido
                            //                        if(movimento[0][0] == -3){//roque grande
                            //                            if(reiPretoOk && torrePretaEsq){
                            //
                            //                            }
                            //                        }
                            //                        else if(movimento[0][0] == -4){//roque pequeno
                            //                            if(reiPretoOk && torrePretaDir){
                            //
                            //                            }
                            //                            else{
                            //movimentoValido = posicaoPeca.movimento(movimento[0], movimento[1], "preto",false);
                            movimentoValido = posicaoPeca.movimento(movimento[0], movimento[1], "preto");

                        }

                        if (movimentoValido){
                            limparPosicao(movimento[0], movimento[1]);//caso o movimento seja valido a posicao inicial e apagada e o peao se move
                            System.out.println(Arrays.toString(movimento[0]) +" "+ Arrays.toString(movimento[1]));

                            if (xeque("branco", "rei")){
                                System.out.println("O rei branco esta em cheque");
                            }
                            if (xeque("preto", "rei")){
                                System.out.println("O rei preto esta em cheque");
                            }
                            break;//reinicia o loop de rodada
                        }
                        System.out.println("Jogada invalida. Tente de novo");
                    } }
            }
        }while (desistencia == 0);//roda enquanto nao ha desistencia
    }

    private static boolean xeque(String cor, String tipo){//aviso de porqueira e gambiarra
        if(tipo.equals("rei")){
            for(int i = 0; i < 8; i++){//+desce, -sobe
                for(int j = 0; j < 8; j++){//+direita, -esquerda
                    if(posicao[i][j].tipo().equals("rei") && posicao[i][j].cor().equals(cor)){//procura pelo rei da cor testada
                        Rei rei = new Rei(cor);
                        posicao[i][j] = rei;
                        System.out.println(j + "x, " + i + "y "+rei.cor());

                        for(int k = 0; k < 8; k++){//+desce, -sobe
                            for(int l = 0; l < 8; l++){//+direita, -esquerda
                                if(!posicao[k][l].tipo().equals("vazio") && posicao[k][l].cor() != null){
                                    if(!posicao[k][l].cor().equals(cor)){
                                        Posicao ameaca = posicao[k][l];
                                        System.out.println(l + "x, " + k + "y peca " + ameaca.tipo() + " " + ameaca.cor());
                                        for(int x = 0; x<8 ; x++){
                                            String tipoAmeaca = ameaca.tipo();

                                            if(k == i + x && l == j + x){
                                                int checar1 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i + y][j + y].tipo().equals("vazio") && (posicao[i + y][j + y].cor().equals(cor)) || !posicao[i + y][j + y].equals(ameaca)){
                                                        continue;
                                                    }
                                                    else{
                                                        checar1--;
                                                    }
                                                    if(checar1 == 0 && (((tipoAmeaca.equals("bispo") || tipoAmeaca.equals("dama"))) || (k == i + 1 && l == j + 1 && (tipoAmeaca.equals("peao") || tipoAmeaca.equals("rei"))))){
                                                        System.out.println("esse1");
                                                        System.out.println(checar1);
                                                        return true;
                                                    }
                                                }
                                            }

                                            if(k == i + x && l == j - x){
                                                int checar2 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i + y][j - y].tipo().equals("vazio") && (posicao[i + y][j - y].cor().equals(cor) || !posicao[i + y][j - y].equals(ameaca))){
                                                        continue;
                                                    }
                                                    else{
                                                        checar2--;
                                                    }
                                                    if(checar2 == 0 && (((tipoAmeaca.equals("bispo") || tipoAmeaca.equals("dama"))) || (k == i + 1 && l == j - 1 && (tipoAmeaca.equals("peao") || tipoAmeaca.equals("rei"))))){
                                                        System.out.println("esse2");
                                                        System.out.println(checar2);
                                                        return true;
                                                    }
                                                }
                                            }

                                            if(k == i - x && l == j + x){
                                                int checar3 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i - y][j + y].tipo().equals("vazio") && (posicao[i - y][j + y].cor().equals(cor) || !posicao[i - y][j + y].equals(ameaca))){
                                                        continue;
                                                    }
                                                    else{
                                                        checar3--;
                                                    }
                                                    if(checar3 == 0 && (((tipoAmeaca.equals("bispo") || tipoAmeaca.equals("dama"))) || (k == i - 1 && l == j + 1 && (tipoAmeaca.equals("peao") || tipoAmeaca.equals("rei"))))){
                                                        System.out.println("esse3");
                                                        System.out.println(checar3);
                                                        return true;
                                                    }
                                                }
                                            }

                                            if(k == i - x && l == j - x){
                                                int checar4 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i - y][j - y].tipo().equals("vazio") && (posicao[i - y][j - y].cor().equals(cor) || !posicao[i - y][j - y].equals(ameaca))){
                                                        continue;
                                                    }
                                                    else{
                                                        checar4--;
                                                    }
                                                    if(checar4 == 0 && (((tipoAmeaca.equals("bispo") || tipoAmeaca.equals("dama"))) || (k == i - 1 && l == j - 1 && (tipoAmeaca.equals("peao") || tipoAmeaca.equals("rei"))))){
                                                        System.out.println("esse4");
                                                        System.out.println(checar4);
                                                        return true;
                                                    }
                                                }
                                            }

                                            if(k == i + x && l == j){
                                                int checar5 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i + y][j].tipo().equals("vazio") && (posicao[i + y][j].cor().equals(cor) || !posicao[i + y][j].equals(ameaca))){
                                                        continue;
                                                    }
                                                    else{
                                                        checar5--;
                                                    }
                                                    if(checar5 == 0 && (((tipoAmeaca.equals("torre") || tipoAmeaca.equals("dama"))) || (k == i + 1 && tipoAmeaca.equals("rei")))){
                                                        System.out.println("esse5");
                                                        System.out.println(checar5);
                                                        return true;
                                                    }
                                                }
                                            }

                                            if(k == i - x && l == j){
                                                int checar6 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i - y][j].tipo().equals("vazio") && (posicao[i - y][j].cor().equals(cor) || !posicao[i - y][j].cor().equals(cor)) && !posicao[i - y][j].equals(ameaca)){
                                                        continue;
                                                    }
                                                    else{
                                                        checar6--;
                                                    }
                                                    if(checar6 == 0 && (((tipoAmeaca.equals("torre") || tipoAmeaca.equals("dama"))) || (k == i - 1 && tipoAmeaca.equals("rei")))){
                                                        System.out.println(checar6);
                                                        System.out.println("esse6");
                                                        return true;
                                                    }
                                                }
                                            }
                                            if(k == i && l == j + x){
                                                int checar7 = x;
                                                for(int y = 0; y <= x; y++){
                                                    if(!posicao[i][j + y].tipo().equals("vazio") && (posicao[i][j + y].cor().equals(cor) || !posicao[i][j + y].equals(ameaca))){
                                                        continue;
                                                    }
                                                    else{
                                                        checar7--;
                                                    }
                                                    if(checar7 == 0 && (((tipoAmeaca.equals("torre") || tipoAmeaca.equals("dama"))) || (l == j + 1 && tipoAmeaca.equals("rei")))){
                                                        System.out.println("esse7");
                                                        System.out.println(checar7);
                                                        return true;
                                                    }
                                                }
                                            }
                                            if(k == i && l == j - x){
                                                int checar8 = x;
                                                for(int y=0; y<=x; y++){
                                                    if(!posicao[i][j - y].tipo().equals("vazio") && (posicao[i][j - y].cor().equals(cor) || !posicao[i][j - y].equals(ameaca))){
                                                        continue;
                                                    }
                                                    else{
                                                        checar8--;
                                                    }
                                                    if(checar8 == 0 && (((tipoAmeaca.equals("torre") || tipoAmeaca.equals("dama"))) || (l == j - 1 && tipoAmeaca.equals("rei")))){
                                                        System.out.println("esse8");
                                                        System.out.println(checar8);
                                                        return true;
                                                    }
                                                }
                                            }
                                            int posicaoRelativaX = l-j;
                                            int posicaoRelativaY = k-i;

                                            int testeCavalo = posicaoRelativaX + posicaoRelativaY;

                                            switch (testeCavalo){
                                                case 1 :
                                                    if(tipoAmeaca.equals("cavalo")){
                                                        return true;
                                                    }
                                                    break;
                                                case -1 :
                                                    if(tipoAmeaca.equals("cavalo")){
                                                        return true;
                                                    }
                                                    break;
                                                case 3 :
                                                    if(tipoAmeaca.equals("cavalo")){
                                                        return true;
                                                    }
                                                    break;
                                                case -3 :if(tipoAmeaca.equals("cavalo")){
                                                    return true;
                                                }
                                                    break;
                                                default :
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private static String nome(int numeroJogador, String nomeAnterior){

        String nome;

        while(true){//leitura dos nomes
            System.out.print("Jogador " + numeroJogador + " digite seu nome:\n ");
            nome = scan.nextLine();

            if(!nome.isEmpty() && !nome.equals(nomeAnterior)) {//checa se o nome esta vazio ou e igual ao anterior
                break;
            }

            else{
                System.out.println("Nome invalido. Tente de novo.");
            }
        }
        return nome;
    }

    public static void posicionar(){

        for(int i = 0; i < 8; i++){
            //posicao[1][i] = new Limpar();
            posicao[1][i] = new Peao("preto");//peoes de cima
        }

        //posicao[0][0] = new Limpar();
        posicao[0][0] = new Torre("preto");
        //posicao[0][1] = new Limpar();
        posicao[0][1] = new Cavalo("preto");
        posicao[0][2] = new Bispo("preto");
        //posicao[0][3] = new Limpar();
        posicao[0][3] = new Dama("preto");
        Rei reiPreto = new Rei("preto");
        posicao[0][4] = reiPreto;
        posicao[0][5] = new Bispo("preto");
        //posicao[0][6] = new Limpar();
        posicao[0][6] = new Cavalo("preto");
        //posicao[0][7] = new Limpar();
        posicao[0][7] = new Torre("preto");

        for(int i = 2; i < 6; i++){
            for(int j = 0; j < 8; j++){
                posicao[i][j] = new Limpar();//vazio do meio
            }
        }

        for(int i = 0; i < 8; i++){
            //posicao[6][i] = new Limpar();
            posicao[6][i] = new Peao("branco");//peoes de baixo
        }

        //posicao[7][0] = new Limpar();
        posicao[7][0] = new Torre("branco");
        //posicao[7][1] = new Limpar();
        posicao[7][1] = new Cavalo("branco");
        posicao[7][2] = new Bispo("branco");
        //posicao[7][3] = new Limpar();
        posicao[7][3] = new Dama("branco");
        Rei reiBranco = new Rei("branco");
        posicao[7][4] = reiBranco;
        posicao[7][5] = new Bispo("branco");
        //posicao[7][6] = new Limpar();
        posicao[7][6] = new Cavalo("branco");
        //posicao[7][7] = new Limpar();
        posicao[7][7] = new Torre("branco");

    }

    private static void limparPosicao(int[] moverDe, int[] moverPara){//limpa posicao inicial apos um movimento
        posicao[moverPara[1]][moverPara[0]] = posicao[moverDe[1]][moverDe[0]];
        posicao[moverDe[1]][moverDe[0]] = new Limpar();
    }

    private static void printarTabuleiro(){//design do tabuleiro

        System.out.print("\n   ");

        for(int i = 0; i < (Jogo.coordLetra.length-1); i++){//para no h pois o I é apenas para desistencia, letras em cima
            System.out.print("  -" + Jogo.coordLetra[i] + "- ");
        }

        System.out.print("\n   ");

        for(int i = 0; i < 8; i++){//divisor das letras de cima pro tabuleiro
            System.out.print("=-----");
        }

        System.out.print("=\n");

        for(int i = 0; i < 8; i++){//numeros a esquerda

            System.out.print("-" + (8 - i) + " |");

            for(Posicao j: posicao[i]){//printa o que esta na posicao, seja peca ou vazio
                System.out.print(j.print() + "|");
            }

            System.out.print(" " + (8 - i) + "-");//numeros a direita
            System.out.print("\n   ");

            for(int j = 0; j < 8; j++){//divisor entre os espacos
                System.out.print("=-----");
            }

            System.out.print("=\n");

        }

        System.out.print("   ");

        for(int i = 0; i < (Jogo.coordLetra.length-1); i++){//letras em baixo
            System.out.print("  -" + Jogo.coordLetra[i] + "- ");
        }

        System.out.print("\n  -COMANDO PARA DESISTENCIA >>>> I9:I9 OU \"DESISTIR\"-  \n\n");

    }
/*
private static boolean roque(){

return true;
}
*///pre protoripo de roque
}